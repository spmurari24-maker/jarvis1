"""JARVIS safety-first assistant foundation."""

__version__ = "0.1.0"
