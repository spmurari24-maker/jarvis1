"""Demonstration skill package."""
